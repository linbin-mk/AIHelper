const SCRIPT_PATH = '~/.aimon/scripts/touchbar-session.sh'
const DEFAULT_PROJECT = 'N/A'
const DEFAULT_TITLE = 'Untitled'
const STATUS_WORKING = 'working'
const STATUS_DONE = 'done'
const STATUS_PENDING = 'pending'
const EDITOR_APP = process.env.AIMON_EDITOR_APP || 'Visual Studio Code'

const sessionMap = new Map()
const pendingCreates = new Set()

function buildScriptPath() {
  if (SCRIPT_PATH.startsWith('~')) {
    const home = process.env.HOME || '~'
    return SCRIPT_PATH.replace('~', home)
  }
  return SCRIPT_PATH
}

function dirName(path) {
  if (!path) return DEFAULT_PROJECT
  const parts = path.replace(/\/$/, '').split('/')
  const name = parts[parts.length - 1]
  return name.length > 8 ? name.slice(0, 8) : name
}

function allSubAgentsDone(entry) {
  for (const sa of entry.subAgents.values()) {
    if (sa.status === 'working') return false
  }
  return true
}

function cleanTitle(raw) {
  return raw.replace(/\s*\(.*\)$/, '').trim()
}

async function ensureCardCreated(dir, project, title, sessionId, $, log) {
  const entry = sessionMap.get(sessionId)
  if (entry && entry.touchbarId) {
    const scriptPath = buildScriptPath()
    const check = await $`${scriptPath} status ${entry.touchbarId} ${STATUS_WORKING}`.nothrow()
    if (check.exitCode === 0) {
      return entry.touchbarId
    }
    entry.touchbarId = null
  }

  if (pendingCreates.has(dir)) {
    return null
  }
  pendingCreates.add(dir)

  try {
    const scriptPath = buildScriptPath()
    const result = await $`${scriptPath} start ${project} ${title} ${dir} ${EDITOR_APP}`.nothrow()
    const touchbarId = result.stdout.toString().trim()
    if (touchbarId) {
      if (!entry) {
        sessionMap.set(sessionId, { touchbarId, project, title, dir, primaryId: sessionId, subAgents: new Map(), isWaitingForUser: false })
      } else {
        entry.touchbarId = touchbarId
        entry.project = project
        entry.title = title
      }
      await log('info', `card created: ${touchbarId} [${project}] ${title}`)
      return touchbarId
    }
    await log('info', `card create failed: ${sessionId}`)
  } finally {
    pendingCreates.delete(dir)
  }
  return null
}

const server = async ({ client, $ }) => {
  const log = (level, msg) => client.app.log({ body: { service: 'session-monitor', level, message: msg } }).catch(() => {})

  await log('info', 'plugin loaded')

  return {
    'experimental.text.complete': async ({ sessionID }, output) => {
      const entry = sessionMap.get(sessionID)
      if (!entry || !entry.touchbarId) return

      if (!entry.isWaitingForUser) return

      const scriptPath = buildScriptPath()
      await $`${scriptPath} status ${entry.touchbarId} ${STATUS_PENDING}`.nothrow().text()
      await log('info', `pending (text complete): ${entry.touchbarId}`)
    },

    'tool.execute.before': async (input) => {
      if (input.tool === 'question') {
        const entry = sessionMap.get(input.sessionID)
        if (entry) {
          entry.isWaitingForUser = true
        }
      }
    },

    'tool.execute.after': async (input) => {
      if (input.tool === 'question') {
        const entry = sessionMap.get(input.sessionID)
        if (entry && entry.touchbarId) {
          entry.isWaitingForUser = false
          const scriptPath = buildScriptPath()
          await $`${scriptPath} status ${entry.touchbarId} ${STATUS_WORKING}`.nothrow().text()
          await log('info', `question answered: ${entry.touchbarId} -> working`)
        }
      }
    },

    'chat.message': async ({ sessionID }, output) => {
      if (output.message?.role !== 'user') return

      const entry = sessionMap.get(sessionID)
      const dir = process.cwd()

      if (!entry || !entry.touchbarId) {
        const project = entry ? entry.project : dirName(dir)
        const sessionTitle = entry ? entry.title : DEFAULT_TITLE

        if (!entry) {
          sessionMap.set(sessionID, { touchbarId: null, project, title: sessionTitle, dir, primaryId: sessionID, subAgents: new Map(), isWaitingForUser: false })
        }

        await ensureCardCreated(dir, project, sessionTitle, sessionID, $, log)
        return
      }

      const scriptPath = buildScriptPath()

      try {
        await $`${scriptPath} status ${entry.touchbarId} ${STATUS_WORKING}`
        entry.isWaitingForUser = false
      } catch {
        await log('info', `${entry.touchbarId} cleared, recreating`)
        entry.touchbarId = null
        await ensureCardCreated(entry.dir, entry.project, entry.title, sessionID, $, log)
      }
    },

    event: async ({ event }) => {
      const scriptPath = buildScriptPath()

      try {
        const type = event?.type
        if (!type) return

        if (type === 'tool.execute.before') {
          const sessionID = event.properties.sessionID
          if (!sessionID) return
          const entry = sessionMap.get(sessionID)
          if (!entry || !entry.touchbarId) return

          await $`${scriptPath} status ${entry.touchbarId} ${STATUS_WORKING}`.nothrow().text()
          return
        }

        if (type === 'session.created') {
          const { id, directory, title, parentID } = event.properties.info
          if (!directory) return

          if (sessionMap.has(id)) return

          if (parentID) {
            let parentEntry = sessionMap.get(parentID)

            if (!parentEntry || !parentEntry.touchbarId) {
              const project = dirName(directory)
              const sessionTitle = title || DEFAULT_TITLE
              const touchbarId = await ensureCardCreated(directory, project, sessionTitle, parentID, $, log)
              if (!touchbarId) return
              parentEntry = sessionMap.get(parentID)
              if (!parentEntry) return
            }

            sessionMap.set(id, parentEntry)
            const subTitle = cleanTitle(title) || `agent-${id.slice(0, 8)}`
            parentEntry.subAgents.set(id, { title: subTitle, status: 'working' })
            await $`${scriptPath} subagent ${parentEntry.touchbarId} ${id} ${subTitle} working`.nothrow()
            await log('info', `session.created sub: ${id.slice(0, 8)} -> card ${parentEntry.touchbarId}, sub: ${subTitle}`)
            return
          }

          const project = dirName(directory)
          const sessionTitle = title || DEFAULT_TITLE
          await ensureCardCreated(directory, project, sessionTitle, id, $, log)
          return
        }

        if (type === 'permission.asked') {
          const sessionID = event.properties.sessionID
          if (!sessionID) return
          const entry = sessionMap.get(sessionID)
          if (!entry || !entry.touchbarId) return

          entry.isWaitingForUser = true
          await $`${scriptPath} rename ${entry.touchbarId} ${entry.title}·授权待确认`.nothrow().text()
          await $`${scriptPath} status ${entry.touchbarId} ${STATUS_PENDING}`.nothrow().text()
          await log('info', `permission.asked: ${entry.touchbarId} -> pending`)
          return
        }

        if (type === 'permission.replied') {
          const sessionID = event.properties.sessionID
          if (!sessionID) return
          const entry = sessionMap.get(sessionID)
          if (!entry || !entry.touchbarId) return

          entry.isWaitingForUser = false
          await $`${scriptPath} rename ${entry.touchbarId} ${entry.title}`.nothrow().text()
          await $`${scriptPath} status ${entry.touchbarId} ${STATUS_WORKING}`.nothrow().text()
          await log('info', `permission.replied: ${entry.touchbarId} -> working`)
          return
        }

        if (type === 'session.error') {
          const sessionID = event.properties.sessionID
          if (!sessionID) return
          const entry = sessionMap.get(sessionID)
          if (!entry || !entry.touchbarId) return

          if (sessionID !== entry.primaryId) return

          await $`${scriptPath} rename ${entry.touchbarId} ${entry.title}·错误`.nothrow().text()
          await log('error', `session.error: ${entry.touchbarId}`)
          return
        }

        if (type === 'session.idle') {
          const sessionID = event.properties.sessionID
          if (!sessionID) return

          const entry = sessionMap.get(sessionID)
          if (!entry || !entry.touchbarId) return

          if (sessionID !== entry.primaryId) {
            const sub = entry.subAgents.get(sessionID)
            if (sub) {
              sub.status = 'done'
              await $`${scriptPath} subagent ${entry.touchbarId} ${sessionID} ${sub.title} done`.nothrow()
              await log('info', `sub-agent done: ${sessionID.slice(0, 8)} -> card ${entry.touchbarId}`)
            }
            return
          }

          if (!allSubAgentsDone(entry)) {
            await log('info', `session.idle deferred (sub-agents still working): ${entry.touchbarId}`)
            return
          }

          await $`${scriptPath} status ${entry.touchbarId} ${STATUS_DONE}`.nothrow().text()
          await log('info', `done (idle): ${entry.touchbarId} -> done`)
          return
        }

        if (type === 'session.status') {
          const { sessionID, status } = event.properties
          if (!sessionID || !status) return
          if (status.type !== 'idle') return

          const entry = sessionMap.get(sessionID)
          if (!entry || !entry.touchbarId) return

          if (sessionID !== entry.primaryId) {
            const sub = entry.subAgents.get(sessionID)
            if (sub) {
              sub.status = 'done'
              await $`${scriptPath} subagent ${entry.touchbarId} ${sessionID} ${sub.title} done`.nothrow()
              await log('info', `sub-agent done (status): ${sessionID.slice(0, 8)} -> card ${entry.touchbarId}`)
            }
            return
          }

          if (!allSubAgentsDone(entry)) {
            await log('info', `session.status deferred (sub-agents still working): ${entry.touchbarId}`)
            return
          }

          await $`${scriptPath} status ${entry.touchbarId} ${STATUS_DONE}`.nothrow().text()
          await log('info', `done (status idle): ${entry.touchbarId} -> done`)
          return
        }

        if (type === 'session.updated') {
          const { id, title } = event.properties.info
          const entry = sessionMap.get(id)
          if (!entry || !entry.touchbarId) return

          const newTitle = title || DEFAULT_TITLE

          if (id !== entry.primaryId) {
            const sub = entry.subAgents.get(id)
            if (sub) {
              sub.title = newTitle
              await $`${scriptPath} subagent ${entry.touchbarId} ${id} ${newTitle} ${sub.status}`.nothrow()
              await log('info', `sub-agent title updated: ${id.slice(0, 8)} -> ${newTitle}`)
            }
            return
          }

          entry.title = newTitle
          await $`${scriptPath} rename ${entry.touchbarId} ${newTitle}`.nothrow().text()
          return
        }

        if (type === 'session.deleted') {
          const { id } = event.properties.info
          const entry = sessionMap.get(id)
          if (!entry || !entry.touchbarId) return

          if (id !== entry.primaryId) {
            const sub = entry.subAgents.get(id)
            if (sub) {
              sub.status = 'done'
              await $`${scriptPath} subagent ${entry.touchbarId} ${id} ${sub.title} done`.nothrow()
            }
            await log('info', `session.deleted (sub-agent): ${id.slice(0, 8)}`)
            sessionMap.delete(id)
            return
          }

          await $`${scriptPath} done ${entry.touchbarId}`.nothrow().text()
          sessionMap.delete(id)
          await log('info', `deleted: ${entry.touchbarId}`)
          return
        }
      } catch (e) {
        // silently ignore
      }
    }
  }
}

export default { id: 'session-monitor', server }
